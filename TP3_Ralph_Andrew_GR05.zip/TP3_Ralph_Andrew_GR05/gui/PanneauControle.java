/**
 * Description:
 * Cette classe permet de creer le panneau de controle qui contient le controle
 * du volume ainsi que le changement d'octave
 * @author Ralph Kobersy et Andrew Kobersy
 * @version H2020
 */
package gui;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JSlider;
import javax.swing.JTextField;
import javax.swing.event.ChangeEvent;
import javax.swing.event.ChangeListener;

import audio.AudioConstantes;
import audio.ModuleAudio;

public class PanneauControle {
	
	//Attributs privees de la classe PanneauControle
	private JPanel panneau;
	private JSlider ctrlVolume;
	private JButton boutonDecremente;
	private JButton boutonIncremente;
	private JTextField numeroOctave;
	private int numeroOctaveChiffre;
	private JLabel etiquetteVolume;
	private JLabel etiquetteOctave;
	private PanneauClavier panneauClavier;
	private ModuleAudio son;
	private int mode;
	private PanneauEnregistrement panneauEnregistrement;
	private int[] toucheClavier= {KeyEvent.VK_A,KeyEvent.VK_W,KeyEvent.VK_S,
								  KeyEvent.VK_E,KeyEvent.VK_D,KeyEvent.VK_F,
								  KeyEvent.VK_T,KeyEvent.VK_G,KeyEvent.VK_Y,
								  KeyEvent.VK_H,KeyEvent.VK_U,KeyEvent.VK_J,
								  KeyEvent.VK_K};
	
	/*
	 * *************************************
	 * LE CONSTRUCTEURS
	 * *************************************
	 */
	public PanneauControle(int volume, int numeroOctaveChiffre
							,PanneauClavier panneauClavier
							,ModuleAudio son
							,PanneauEnregistrement panneauEnregistrement){
		
		this.numeroOctaveChiffre=numeroOctaveChiffre;
		this.panneauClavier=panneauClavier;
		this.son=son;
		this.panneauEnregistrement=panneauEnregistrement;
		
		//On appel la methode qui cree le panneau de controle
		initPanneauControle(volume,son,panneauEnregistrement);
	
	}
	
	/*
	 * ****************************************
	 * LES METHODES
	 * ****************************************
	 */
	
	/**
	 * Methode qui permet d'initialiser le panneau de controle
	 * 
	 * @param volume qui est le volume du son
	 * @param son qui permet de creer le son des notes
	 * @param panneauEnregistrement panneau qui permet d'enregistrer la melodie
	 * @return aucune valeur de retour 
	 */
	public void initPanneauControle(int volume, ModuleAudio son
								,PanneauEnregistrement panneauEnregistrement) {
		
		//On appel les methodes qui cree le panneau de controle
		creerPanneauControle();
		creerEtiquetteVolume();
		ajouterEtiquetteVolumeAuPanneau();
		creerVolumeControle(volume,son);
		ajouterVolumeAuPanneau();
		creerEtAjouterEcouteurPourLeVolume(volume,son);
		creerBoutonOctave();
		creerEtiquetteOctave();
		ajouterEtiquetteOctaveAuPanneau();
		ajouterBoutonDecrementeAuPanneau();
		creerAffichageOctave();
		ajouterEtiquetteOctave();
		ajouterBoutonIncrementeAuPanneau();
		ajouterPanneauEnregistrement(panneauEnregistrement);
		creerEtAjouterEcouteurOctave();
		ajouterEcouteurModeClavierAuTouche();
	}
	
	/*
	 * **********************************
	 * LES METHODES
	 * **********************************
	 */
	
	/**
	 * Methode qui permet de creer le panneau de controle
	 * 
	 * @param aucun parametre
	 * @return aucune valeur de retour 
	 */
	public void creerPanneauControle() {
		
		//On instancie le panneau de controle
		panneau= new JPanel();
		
		//On donne une couleur de fond pour le panneau de controle
	    panneau.setBackground(Color.LIGHT_GRAY);
	}
	
	/**
	 * Methode qui permet de creer le slider pour le volume
	 * 
	 * @param aucun parametre
	 * @return aucune valeur de retour 
	 */
	public void creerVolumeControle(int volume, ModuleAudio son) {
		
		//On instancie le controle du volume qui est un JSlier
		ctrlVolume= new JSlider(JSlider.HORIZONTAL,AudioConstantes.MIN_VOLUME
								,AudioConstantes.MAX_VOLUME
								,volume);
		
		//On donne une couleur de fond pour le controle du volume
		ctrlVolume.setBackground(Color.LIGHT_GRAY);
		
		//On controle le volume
		son.setVolume(volume);
		
		//On donne la valeur minimum
		ctrlVolume.setMinimum(0);
		
		//On donne la valeur maximum
	    ctrlVolume.setMaximum(10);
	    
	    
	    ctrlVolume.setPaintLabels(true);
	    ctrlVolume.setPaintTicks(true);
	    ctrlVolume.setSnapToTicks(true);
	    ctrlVolume.setMajorTickSpacing(1);
	}
	
	/**
	 * Methode qui permet de creer une etiquette pour le volume
	 * 
	 * @param aucun parametre 
	 * @return aucune valeur de retour
	 */
	public void creerEtiquetteVolume() {
		
		//On instancie l'etiquette du volume 
		 etiquetteVolume = new JLabel("Volume: "+ AudioConstantes.VOLUME_INIT); 
	}
	
	/**
	 * Methode qui permet de creer une etiquette pour l'octave
	 * 
	 * @param aucun parametre
	 * @return aucune valeur de retour 
	 */
	public void creerEtiquetteOctave() {
		
		//On instancie l'etiquette pour l'octave
		etiquetteOctave= new JLabel("Octave:");
	}
	
	/**
	 * Methode qui permet de creer les deux boutons pour changer l'octave 
	 * du clavier 
	 * 
	 * @param aucun parametre
	 * @return aucune valeur de retour 
	 */
	public void creerBoutonOctave() {
		
		//Creation des boutons pour incrementer et decrementer
		boutonDecremente= new JButton("<");
		boutonIncremente= new JButton(">");
	}
	
	/**
	 * Methode qui permet d'instancier une etiquette pour le numero
	 * d'octave
	 * 
	 * @param aucun parametre
	 * @return aucun retour
	 */
	public void creerAffichageOctave() {
		
		//On instancie un objet de type JTextField
		numeroOctave= new JTextField();
		
		//Permet d'afficher le numero d'octave
		numeroOctave.setText(""+ numeroOctaveChiffre);
		
		//Le texte n'est pas editable 
		numeroOctave.setEditable(false);
	}
	
	/**
	 * Methode qui permet d'ajouter l'etiquette au panneau principal
	 * 
	 * @param aucun parametre
	 * @return aucun retour
	 */
	public void ajouterEtiquetteOctave() {
		
		//On ajoute l'etiquette de l'octave au panneau de controle
		panneau.add(numeroOctave);
	}
	
	/**
	 * Methode qui permet d'ajouter le bouton de decrementation
	 * octaves au panneau de controle
	 * 
	 * @param aucun parametre
	 * @return aucun retour
	 */
	public void ajouterBoutonDecrementeAuPanneau() {
		
		//On ajoute le bouton pour decrementer l'octave au panneau de controle
		panneau.add(boutonDecremente);
		
	}
	
	/**
	 * Methode qui permet d'ajouter le bouton d'incrementation octaves 
	 * au panneau de controle
	 * 
	 * @param aucun parametre
	 * @return aucun retour
	 */
	public void ajouterBoutonIncrementeAuPanneau() {
		
		//On ajoute le bouton pour incrementer l'octave au panneau de controle
		panneau.add(boutonIncremente);	
	}
	
	/**
	 * Methode qui permet d'ajouter le panneau d'enregistrement au panneau 
	 * de cotrole
	 * 
	 * @param panneauEnregistrement qui permet d'enregistrer la melodie
	 * @return aucune valeur de retour
	 */
	public void ajouterPanneauEnregistrement
								(PanneauEnregistrement panneauEnregistrement) {
		
		//On ajoute le panneau d'enregistrement au panneau de controle
		panneau.add(panneauEnregistrement);
	}
	
	/**
	 * Methode qui permet de creer et d'ajouter un ecouteur pour le volume 
	 * 
	 * @param aucun parametre 
	 * @return aucune valeur de retour 
	 */
	public void creerEtAjouterEcouteurPourLeVolume(int volume,ModuleAudio son) {
		
		//On instancie l'ecouteur pour le controle du volume 
		EcouteurVolume ecouterSon= new EcouteurVolume(son);
		
		//On ajoute l'ecouteur au controle du volume
		ctrlVolume.addChangeListener(ecouterSon); 
	}
	
	/**
	 * Methode qui permet de creer et d'ajouter un eceouteur au bouton d'octave
	 * 
	 * @param aucun parametre
	 * @return aucun retour
	 */
	public void creerEtAjouterEcouteurOctave() {
		
		//On instancie l'ecouteur pour l'ecouteur de l'octave
		EcouteurOctave ecouteurBouton= new EcouteurOctave();
		
		//On ajoute l'ecouteur au bouton pour decrementer
		boutonDecremente.addActionListener(ecouteurBouton);
		
		//On ajoute l'ecouteur au bouton pour incrementer
		boutonIncremente.addActionListener(ecouteurBouton);
	}
	
	/**
	 * Methode qui permet d'ajouter le volume au panneau de controle 
	 * 
	 * @param aucun parametre
	 * @return aucune valeur de retour 
	 */
	public void ajouterVolumeAuPanneau() {
		
		//On ajoute le controle du volume au panneau de controle 
		panneau.add(ctrlVolume);
	}
	
	/**
	 * Methode qui permet d'ajouter l'etiquette du volume au panneau de controle
	 * 
	 * @param aucun parametre.
	 * @return aucune valeur de retour 
	 */
	public void ajouterEtiquetteVolumeAuPanneau() {
		
		//On ajoute l'etiquette du volume au panneau de controle
		panneau.add(etiquetteVolume);
	}
	
	/**
	 * Methode qui permet d'ajouter l'etiquette de l'octave au panneau 
	 * de controle
	 * 
	 * @param aucun parametre
	 * @return aucun valeur de retour
	 */
	public void ajouterEtiquetteOctaveAuPanneau() {
		
		//On ajoute l'etiquette de l'octave au panneau de controle
		panneau.add(etiquetteOctave);
	}
	
	/**
	 * Methode qui permet d'ajouter l'ecouteur du clavier a chacune des touches
	 * du clavier
	 * 
	 * @param aucun parametre
	 * @return aucune valeur de retour 
	 */
	public void ajouterEcouteurModeClavierAuTouche() {
		
		//On instancie l'ecouteur pour les touches du clavier
		EcouteurModeClavier ecouteurClavier= new EcouteurModeClavier();
		
		//On ajoute l'ecouteur au panneau de controle
		panneau.addKeyListener(ecouteurClavier);
		
		//On garde le focus pour le panneau
		panneau.requestFocusInWindow();
		
		panneau.setFocusable(true);
		
		//On valide le panneau
		panneau.validate();
	}
	
	/*
	 * ******************************
	 * LES ACCESSEURS
	 * ******************************
	 */
	
	/**
	 * Accesseur pour le panneau de controle
	 * 
	 * @param aucun parametre 
	 * @return retourne le panneau de controle de type JPanel
	 */
	public JPanel getPanneauControle() {
		
		//On retourne le panneau de controle
		return panneau;
	}
	
	/**
	 * Accesseur qui permet d'avoir la valeur de l'octave
	 * 
	 * @param aucun parametre
	 * @return aucune valeur de retour 
	 */
	public int getOctave() {
		
		//On retourne le numero de l'octave
		return numeroOctaveChiffre;
	}
	
	/*
	 * ***************************
	 * LES MUTATEURS
	 * ***************************
	 */
	
	/**
	 * Mutateur pour le mode de jeu du panneau de controle
	 * 
	 * @param mode le mode de jeu choisi
	 * @return aucune valeur de retour 
	 */
	public void setMode(int mode) {
		
		this.mode=mode;
		
		panneau.requestFocusInWindow();
	}
	
	/*
	 * *************************************************
	 * CLASSE PRIVEES POUR LES ECOUTEURS
	 * *************************************************
	 */
	
	//Classe interne pour les ecouteurs
	private class EcouteurVolume implements ChangeListener{
		
		//Attribut de la classe interne
		ModuleAudio son;
		
		//Constructeur de la classe interne
		public EcouteurVolume(ModuleAudio son) {
			
			this.son=son; 
		}
		
		/**
		 * Methode qui permet de changer l'etat du controle du volume lorsqu'on
		 * touche au curseur
		 * 
		 * @param e qui permet de changer l'etat du volume
		 * @return aucune valeur de retour
		 */
		public void stateChanged(ChangeEvent e) {
			
			//Variable qui retient la valeur du volume 
			int valeurBarreVolume = ctrlVolume.getValue();
			
			//On change la valeur selon la position du curseur
			etiquetteVolume.setText("Volume: "+valeurBarreVolume);
			
			//On ajuste le volume selon la position du curseur
			son.setVolume(ctrlVolume.getValue());
			
			//On garde le focus sur le panneau 
			panneau.requestFocusInWindow();
		}
	}
	
	//Classe interne pour l'ecouteur de l'octave
	private class EcouteurOctave implements ActionListener{
		
		/**
		 * Methode qui de faire des actions selon le bouton appuye par 
		 * l'utilisateur
		 * 
		 * @param e qui est un ActionEvent
		 * @return aucune valeur de retour
		 */
		public void actionPerformed(ActionEvent e) {
				
				/*
				 * Si l'utilisateur appuie sur le bouton pour decrementer 
				 * et que l'octave n'est pas au minimum (3)
				 */
				if(e.getSource()==boutonDecremente 
						&& numeroOctaveChiffre > AudioConstantes.MIN_OCTAVE){
					
					//On decremente le numero de l'octave
					numeroOctaveChiffre--;
					
					//On change la valeur de l'octave sur les touches de clavier
					panneauClavier.setOctave(numeroOctaveChiffre);
					
					//On change le texte pour afficher le bon nombre
					numeroOctave.setText(String.valueOf(numeroOctaveChiffre));
					
					//On garde le focus sur le panneau
					panneau.requestFocusInWindow();
					
					//On valide les composantes
					panneau.validate();
	
				}
				/*
				 * Sinon si l'utilisateur appuie sur le bouton pour incremneter 
				 * et que l'octave n'est pas au maximum (5)
				 */
				else if (e.getSource()==boutonIncremente 
						&& numeroOctaveChiffre < AudioConstantes.MAX_OCTAVE){
					
					//On incremente le numero de l'octave 
					numeroOctaveChiffre++;
					
					//On change la valeur de l'octave sur les touches du clavier
					panneauClavier.setOctave(numeroOctaveChiffre);
					
					//On change le texte pour afficher le bon nombre 
					numeroOctave.setText(String.valueOf(numeroOctaveChiffre));
					
					//On garde le focus sur le panneau
					panneau.requestFocusInWindow();
					
					//On valide les composantes
					panneau.validate();
					
				}
		}

	}
	
	/*
	 * Classe privee pour l'ecouteur de chacune des touches en mode clavier
	 */
	private class EcouteurModeClavier implements KeyListener{

		public void keyTyped(KeyEvent e) {
		}
		
		/*
		 * Methode qui permet de jouer une note si on appuie sur une touche
		 * du clavier
		 * @param aucun parametre
		 * @return aucune valeur de retour 
		 */
		public void keyPressed(KeyEvent e) {
			
			//On retient la touche appuyer
			int choixModeClavier = e.getKeyCode();
			
			//On enregistre la note jouee dans un String
			String notePiano="";
			
			//Si l'utilisateur est en mode clavier
			if(mode==ConstantesMode.MODE_CLAVIER) {
				
				//On parcourt le tableau qui contient les lettres a jouees
				for(int i=0;i<toucheClavier.length;++i) {
					
					//Si le choix correspond a la lettre
					if(choixModeClavier==toucheClavier[i]) {
						
						//On retient la variable jouee
						String noteJouer= panneauClavier.getTableauTouche()[i]
														.getNote().getText();
						
						//On joue la note
						son.jouerUneNote(noteJouer);
						
						//Si l'utilisateur est en train d'enregistrer
						if(panneauEnregistrement.getCaFilme()) {
							
							//On ajoute les notes a la collection
							panneauEnregistrement.ajouterNoteMelodie(noteJouer);
						}
						
					}
					
				}
				
			}
			
			//On valide les composantes du panneau
			panneauClavier.validate();
		}
		
		/*
		 * Methode qui joue un silence si on relache la touche du clavier
		 * @param e un key event
		 * @return aucune valeur de retour 
		 */
		public void keyReleased(KeyEvent e) {
			
			//Si l'utilisateur est en mode clavier
			if(mode==ConstantesMode.MODE_CLAVIER) {
				
				//On joue un silence
				son.jouerUnSilence();
			}
		}
		
		
	}

}
