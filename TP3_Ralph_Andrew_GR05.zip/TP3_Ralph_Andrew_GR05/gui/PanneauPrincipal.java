/**
 * Description:
 * Cette classe permet de creer le panneau principal qui contient tous les 
 * autres panneaux du synthetiseur
 * @author Ralph Kobersy et Andrew Kobersy
 * @version H2020
 */
package gui;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.FlowLayout;

import javax.swing.JPanel;

import audio.AudioConstantes;
import audio.ModuleAudio;

public class PanneauPrincipal extends JPanel{
	
	/*
	 * Attributs privee de la classe PanneauPrincipal
	 */
	private PanneauClavier panneauClavier;
	private PanneauControle panneauControle;
	private ModuleAudio son;
	private PanneauEnregistrement panneauEnregistrement;
	
	/*
	 * ****************************
	 * LE CONSTRUCTEUR
	 * ****************************
	 */
	public PanneauPrincipal(int volume,int octave) {
		
		son = new ModuleAudio(volume);
		
		initPanneauPrincipal(volume,octave);
	}
	
	/*
	 * ****************************************
	 * LES METHODES
	 * ****************************************
	 */
	
	/**
	 * Methode qui permet de creer un panneau principal 
	 * 
	 * @param aucun parametre 
	 * @return aucune valeur de retour 
	 */
	public void creerPanneauPrincipal() {
		
		//On met le type de layout
		setLayout(new BorderLayout());
		
		//On met une couleur de fond
		setBackground(Color.LIGHT_GRAY);
	}
	
	/**
	 * Methode qui permet d'initialiser le panneau principal 
	 * 
	 * @param le volume pour le panneau de controle
	 * @param octave pour le panneau de controle
	 * @return aucune valeur de retour
	 */
	public void initPanneauPrincipal(int volume,int octave) {
		
		//On cree le panneau principal
		creerPanneauPrincipal();
				
		//On instancie un objet de type Panneau Enregistrement
		panneauEnregistrement= new PanneauEnregistrement(son,this);
		
		//On instancie un objet de type Panneau Clavier		
		panneauClavier= new PanneauClavier(octave,son,panneauEnregistrement);
		
		//On instancie un objet de type Panneau de controle
		panneauControle = new PanneauControle(volume,octave,panneauClavier,son
											,panneauEnregistrement);
				
		//On ajoute le panneau de controle au panneau principal
		add(panneauControle.getPanneauControle(),BorderLayout.NORTH);
				
		//On ajoute le panneau de clavier au panneau principal
		add(panneauClavier);
		
		//Le mode souris est le choix par defaut
		setMode(ConstantesMode.MODE_SOURIS);		
	}
	
	/*
	 * *********************
	 * LES MUTATEURS
	 * *********************
	 */
	
	/**
	 * Mutateur pour le panneau principal qui permet de mettre une valeur au mode
	 * 
	 * @param mode qui permet de choisir le mode de jeu
	 * @return aucune valeur de retour 
	 */
	public void setMode(int mode) {
		
		//On met le mode pour le panneau de clavier 
		panneauClavier.setMode(mode);
		
		//On met le mode pour le panneau de controle
		panneauControle.setMode(mode);	
	}
	
	/*
	 * ******************************
	 * LES ACCESSEURS
	 * ******************************
	 */
	
	/**
	 * Accesseur qui permet d'avoir le panneau de controle
	 * 
	 * @param aucun parametre
	 * @return panenauControle on retourne le panneau de controle
	 */
	public PanneauControle getControle() {
		
		//On retourne le panneau de controle
		return panneauControle;
	}
	
}
