/**
 * Description:
 * Cette classe permet de creer les touches du clavier 
 * @author Ralph Kobersy et Andrew Kobersy
 * @version H2020
 */
package gui;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.Toolkit;

import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JPanel;

public class ToucheClavier extends JPanel{
	
	/*
	 * Attributs privees de la classe ToucheClavier
	 */
	private String noteJouer;
	private int octaveCourante;
	private Color couleurTouche;
	private JLabel note;
	private Color couleurTexteNote;
	private JButton toucheClavier;
	private int hauteur;
	private int largeur;
	
	/*
	 * ****************************
	 * LE CONSTRUCTEUR
	 * ****************************
	 */
	public ToucheClavier(String noteJouer, Color couleurTouche
						,int octaveCourante,Color couleurTexteNote
						,int largeur,int hauteur) {
		
		
		this.noteJouer=noteJouer;
		this.couleurTouche= couleurTouche;
		this.octaveCourante=octaveCourante;
		this.couleurTexteNote=couleurTexteNote;
		this.largeur=largeur;
		this.hauteur=hauteur;
		
		initToucheClavier();
	}
	
	/**
	 * Methode qui permet de creer les touches du synthetiseur
	 * 
	 * @param aucun param 
	 * @return aucune valeur de retour 
	 */
	public void initToucheClavier() {
		
		creerPanneauToucheClavier(couleurTouche);
		creerNomNote(noteJouer,octaveCourante,couleurTexteNote);
		ajouterEtiquetteAuPanneau();
	}
	
	/*
	 * *************************
	 * LES METHODES
	 * *************************
	 */
	
	/**
	 * Methode qui permet de changer la couleur de fond pour le panneau 
	 * ToucheClavier
	 * 
	 * @param aucun param
	 * @return aucune valeur de retour 
	 */
	public void creerPanneauToucheClavier(Color couleurTouche) {
		
		setLayout(new BorderLayout());    
		Dimension dim = new Dimension(hauteur,largeur);
		setMinimumSize(dim);
		setPreferredSize(dim);
		setMaximumSize(dim);
		setBackground(couleurTouche);
	}
	
	/**
	 * On cree et on ajoute un bouton au panneau de clavier
	 * 
	 * @param aucun parametre 
	 * @return aucune valeur de retour 
	 */
	public void creerBoutonEtAjouterClavier(Color couleurTouche) {
		
		//On instancie un objet de type JButton
		toucheClavier= new JButton();
		
		//La taille du bouton est la meme que celle du panneau de clavier
		toucheClavier.setPreferredSize(this.getSize());
		
		//La couleur du bouton depend de la note
		toucheClavier.setBackground(couleurTouche);
		
		//On ajoute le bouton au clavier
		add(toucheClavier);
	}
	
	/**
	 * Methode qui permet de creer et de mettre la note jouer et le numero de 
	 * l'octave dans l'etiquette de la note
	 * 
	 * @param aucun parametre
	 * @return aucune valeur de retour
	 */
	public void creerNomNote(String noteJouer, int octaveCourante
							,Color couleurTexteNote) {
		
		//On instancie l'etiquette pour la touche
		note = new JLabel(noteJouer + octaveCourante);
		
		//On donne une couleur a l'etiquette
		note.setForeground(couleurTexteNote);
	}
	
	/**
	 * Methode qui permet d'ajouter une etiquette de note au touche du clavier
	 * 
	 * @param aucun parametre
	 * @return aucune valeur de retour
	 */
	public void ajouterEtiquetteNoteAuBouton() {
		
		//On ajoute l'etiquette a la touche du clavier
		toucheClavier.add(note);
	}
	
	/**
	 * Methode qui permet d'ajouter une etiquette de note au touche du clavier
	 * 
	 * @param aucun parametre
	 * @return aucune valeur de retour
	 */
	public void ajouterEtiquetteAuPanneau() {
		
		//On aligne le texte au bas de la touche
		note.setVerticalAlignment(JLabel.BOTTOM);
		
		//On aligne le texte au cnetre de la largeur
		note.setHorizontalAlignment(JLabel.CENTER);
		
		//On ajoute la note au panneau pour la touche
		add(note);
	}

	/*
	 * ********************************
	 * LES ACCESSEURS 
	 * ********************************
	 */
	
	/**
	 * Accesseur pour l'etiquette de la note7
	 * 
	 * @param aucun parametre 
	 * @return note on retourne l'etiquette de la note
	 */
	public JLabel getNote() {
		
		//On retourne l'etiquette de la touche
		return note;
	}

	
}
