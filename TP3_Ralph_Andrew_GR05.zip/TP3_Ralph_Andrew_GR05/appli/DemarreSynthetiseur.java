package appli;

import javax.swing.UIManager;

import audio.AudioConstantes;
import gui.GUISynthetiseur;
import gui.PanneauPrincipal;

/**
 * Description:
 * Cette classe permet de demarrer l'application a l'aide d'un thread
 * @author Ralph Kobersy et Andrew Kobersy
 * @version H2020
 */
public class DemarreSynthetiseur {
	
	public static void main(String[] args) {
		
		//Declaration d'un objet de type GUISynthetiseur
		GUISynthetiseur synthetiseur;
		
		//On cree un thread avec l'objet de type GUISynthetiseur
		Thread t = new Thread(synthetiseur = new GUISynthetiseur(AudioConstantes
															.VOLUME_INIT
															,AudioConstantes
															.OCTAVE_INIT));
		
		//On commence le thread
		t.start();

	}
	
	/**
	 * Methode qui permet de configurer un look and feel compatible 
	 * interplateforme.
	 * @param aucun parametre
	 * @return aucune valeur de retour
	 */
	public static void setLookAndFeel() {
		
		//On essaye de set le look and feel
	   try {
		   
	      UIManager.setLookAndFeel(
	         UIManager.getCrossPlatformLookAndFeelClassName());
	     
	   //Si ca ne marche pas, on lance une exception
	   } catch (Exception e) {
		  
		  //On montre la trace 
	      e.printStackTrace();
	      
	   }
	   
	}
	
	


}
